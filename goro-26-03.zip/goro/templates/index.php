<div class="container-fluid" id="l-app">
    <?php
    if(!get_option('license_key_4RKdeNKeTu')){
        ?>
        <div>
            <div class="alert alert-danger">You need active license key!</div>
        </div>
    <?php } ?>
    <div class="row">
        <div class="col-6">
            <h4>Campaign</h4>
        </div>
        <div class="col-6 text-right">
            <button id="show-modal" class="btn btn-success" @click="showModal = true">Create compaign</button>
        </div>
    </div>
    <hr>

    <!-- use the modal component, pass in the prop -->
    <modal v-if="showModal" @close="createCampaign" @closemodal="close">
        <!--
      you can use custom content here to overwrite
      default content
    -->
        <h3 slot="header">Create campaign</h3>
        <template v-slot:body>
            <div class="form-group alert alert-danger" v-if="errors && errors.all().length">
                <ol>
                    <li v-for="error in errors.all()">{{ error }}</li>
                </ol>
            </div>
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" v-validate="'required'" name="name" placeholder="Enter the name campaign" v-model="campaign.name">
            </div>
            <div class="form-group">
                <label>Keyword</label>
                <multiselect v-model="campaign.keywords" tag-placeholder="Add this as new keyword"
                             placeholder="Search or add a keyword" label="name" track-by="value" :multiple="true"
                             :taggable="true" @tag="addTag" :options="options"
                             v-validate="'required|maxLengthArray:2'" name="keyword"
                ></multiselect>
            </div>
            <div class="form-group">
                <label>Number of post</label>
                <input type="text" class="form-control" name="post_number" v-validate="'required|min_value:1|max_value:1000'" v-model="campaign.post_number">
            </div>
            <div class="form-group">
                <label>Translate: </label>&nbsp;<input type="checkbox" v-model="campaign.translate">
            </div>
            <div class="form-group">
                <label>Language <span v-if="campaign.translate">(From)</span></label>
                <multiselect v-model="campaign.lang"
                             placeholder="Search lang" label="label" track-by="value"
                             :options="campaign.translate ? translateLangs : langs"
                             v-validate="'required'" name="lang"
                ></multiselect>
                <!--                <select name="" class="form-control" v-model="campaign.lang" id="">-->
                <!--                    <option v-for="({value, label}, index) in langs" :key="index" :value="value">{{label}}</option>-->
                <!--                </select>-->
            </div>
            <div class="form-group" v-if="campaign.translate">
                <label>Language <span >(To)</span></label>
                <multiselect v-model="campaign.to"
                             placeholder="Search lang" label="label" track-by="value"
                             :options="translateLangs"
                             v-validate="'required'" name="lang"
                ></multiselect>
            </div>
            <div class="form-group">
                <label>Categories</label>
                <multiselect v-model="campaign.categories"
                             placeholder="Search or add a category" label="name" track-by="value" :multiple="true"
                             :options="categories"
                             v-validate="'required'" name="categories"
                ></multiselect>
            </div>
        </template>
    </modal>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Name</th>
            <th>Keyword</th>
            <th>Post request</th>
            <th>Posted</th>
            <th>State</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="campaign in campaigns">
            <td>{{campaign.name}}</td>
            <td>{{fetchKeyword(campaign.keyword)}}</td>
            <td>{{campaign.post_number}}</td>
            <td>{{campaign.posted}}</td>
            <td>{{getStateName(campaign.state)}}</td>
            <td>
                <button class="btn-sm btn btn-danger" v-if="campaign.state == 0" @click="stopCampaign(campaign)">Stop</button>
                <button class="btn-sm btn btn-danger" @click="deleteCampaign(campaign.id)">Delete</button>
            </td>
        </tr>
        </tbody>
    </table>

    <script type="text/x-template" id="modal-template">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper">
                    <div class="modal-container" style="max-height: calc(100% - 300px); overflow-x: auto">

                        <div class="modal-header">
                            <slot name="header"></slot>
                        </div>

                        <div class="modal-body">
                            <slot name="body"></slot>
                        </div>

                        <div class="modal-footer">
                            <slot name="footer">
                                <button class="modal-default-button btn btn-success" @click="$emit('close')">
                                    Submit
                                </button>
                                <button class="btn btn-primary" @click="$emit('closemodal')">Cancel</button>
                            </slot>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </script>
</div>

<script>
    const categories = <?php echo $categories; ?>;
    const languages = <?php echo $languages; ?>;
    const data = <?php echo $data; ?>;

    jQuery(document).ready(function () {
        /** register modal */
        Vue.component('modal', {
            template: '#modal-template'
        })
        Vue.component('multiselect', window.VueMultiselect.default)

        const maxLengthArray = (value, {max}) => {
            return value.length <= max
        };

        const paramNames = ['max'];

        window.VeeValidate.Validator.extend('maxLengthArray', {
            validate: maxLengthArray,
            getMessage: (field, params) => {
                return `Field ${field} max is ${params[0]}`
            }
        }, {
            paramNames
        })
        
        Vue.use(window.VeeValidate);

        const STATE = {
            0: 'Running',
            1: 'Stop'
        }

        const app = new Vue({
            el: '#l-app',
            data: {
                campaigns: [],
                showModal: false,
                campaign: {
                    keywords: [],
                    post_number: 20,
                    lang: {
                        value: 'en',
                        label: 'Tiếng Anh'
                    },
                    categories: [],
                    name: '',
                    translate: false,
                    to: null
                },
                options: [],
                langs: [],
                categories: [],
                translateLangs: []
            },
            beforeMount() {
                this.categories = categories.map(({cat_ID, cat_name}) => ({
                    value: cat_ID,
                    name: cat_name
                }));
                this.langs = languages.map(({languageCode, languageName}) => ({
                    value: languageCode,
                    label: languageName.simpleText
                }));

                // this.campaigns = data;
            },
            mounted () {
                this.refresh()

                getLangs().then(res => {
                    this.langs = res.map(({languageCode, languageName}) => ({
                        value: languageCode,
                        label: languageName.simpleText
                    }))
                })

                getCategories().then(res => {
                    this.categories = res.map(({cat_ID, cat_name}) => ({
                        value: cat_ID,
                        name: cat_name
                    }))
                })

                getTranslateLanguageSupport().then(res => {
                    try {
                        this.translateLangs = Object.keys(res.translation).map(item => {
                            return {
                                value: item,
                                label: res.translation[item].name
                            }
                        })
                    } catch(e) {}
                })
            },
            methods: {
                refresh() {
                    fetchData().then(res => {
                        this.campaigns = res
                    })
                },
                stopCampaign(campaign) {
                    if(!window.confirm('Do you want to stop this campaign?')) {
                        return;
                    }

                    stopCampaign(campaign.id).then(status => {
                        if (status) {
                            this.notify('Stop success')

                            campaign.state = 1;
                        } else {
                            this.notify('Stop failed', 'warn')
                        }
                    })
                },
                getStateName (state) {
                    return STATE[state]
                },
                deleteCampaign (campaignId) {
                    if(!window.confirm('Do you want to delete?')) {
                        return;
                    }

                    deleteCampaign(campaignId).then(status => {
                        if (status) {
                            this.notify('Delete success')

                            this.refresh()
                        } else {
                            this.notify('Delete failed', 'warn')
                        }
                    })
                },
                notify (message, type = 'success') {
                    jQuery.notify(message, {
                        className: type,
                        position: 'bottom right',
                    })
                },
                addTag (newTab) {
                    const tab = {
                        name: newTab,
                        value: newTab
                    };

                    this.campaign.keywords.push(tab)
                    this.options.push(tab)
                },
                createCampaign() {
                    this.$validator.validate().then(valid => {
                        if (!valid) {
                            this.notify('Form is not valid', 'warn')
                            return
                        }

                        // this.showModal = false
                        const data = {
                            keywords: this.campaign.keywords.map(item => item.value),
                            categories: this.campaign.categories.map(item => item.value),
                            post_number: this.campaign.post_number,
                            lang: this.campaign.lang.value,
                            name: this.campaign.name,
                            translate: this.campaign.translate ? 1 : 0,
                            to: this.campaign.to ? this.campaign.to.value : null
                        }

                        createCampaign(data).then(res => {
                            this.notify(res.message, res.status ? 'success' : 'warn')

                            this.showModal = false
                            this.refresh()
                            this.campaigns = {
                                keywords: [],
                                post_number: 0,
                                lang: 'en',
                                categories: [],
                                name: ''
                            }
                        })
                    });
                },
                close() {
                    this.showModal = false
                },
                fetchKeyword(keyword) {
                    return keyword.replace(/\|/g, ' - ')
                }
            }
        })

        function getTranslateLanguageSupport() {
            return new Promise((res, rej) => {
                jQuery.ajax({
                    url: 'https://api.cognitive.microsofttranslator.com/languages?api-version=3.0',
                    method: 'GET',
                    success: response => {
                        res(response)
                    },
                    error: response => {
                        rej(response)
                    }
                })
            })
        }

        function createCampaign(data) {
            return new Promise(res => {
                jQuery.ajax({
                    url: litAjax.create_campaign,
                    method: 'POST',
                    data,
                    success: response => {
                        res(response)
                    },
                    error: () => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/create_campaign',
                            method: 'POST',
                            data,
                            success: response2 => {
                                res(response2)
                            }
                        })
                    }
                })
            })
        }

        function fetchData () {
            return new Promise(res => {
                jQuery.ajax({
                    url: litAjax.get_campaign,
                    method: 'GET',
                    success: response => {
                        res(response)
                    },
                    error: () => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/get_campaign',
                            method: 'GET',
                            success: response2 => {
                                res(response2)
                            }
                        })
                    }
                })
            })
        }

        function stopCampaign (campaignId) {
            return new Promise((res, rej) => {
                jQuery.ajax({
                    url: litAjax.stop_campaign,
                    method: 'POST',
                    data: {
                        id: campaignId
                    },
                    success: response => {
                        if (response) {
                            res(true)
                        } else {
                            res(false)
                        }
                    },
                    error: err => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/stop_campaign',
                            method: 'POST',
                            data: {
                                id: campaignId
                            },
                            success: response2 => {
                                res(true)
                            },
                            error: () => {
                                rej(false)
                            }
                        })
                    }
                })
            })
        }

        function deleteCampaign (campaignId) {
            return new Promise((res, rej) => {
                jQuery.ajax({
                    url: litAjax.delete_campaign,
                    method: 'POST',
                    data: {
                        id: campaignId
                    },
                    success: response => {
                        if (response) {
                            res(true)
                        } else {
                            res(false)
                        }
                    },
                    error: err => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/delete_campaign',
                            method: 'POST',
                            data: {
                                id: campaignId
                            },
                            success: response2 => {
                                res(true)
                            },
                            error: () => {
                                rej(false)
                            }
                        })
                    }
                })
            })
        }
        
        function getLangs() {
            return new Promise(res => {
                jQuery.ajax({
                    url: litAjax.get_langs,
                    method: 'GET',
                    success: response => {
                        res(response)
                    },
                    error: () => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/get_langs',
                            method: 'GET',
                            success: response2 => {
                                res(response2)
                            }
                        })
                    }
                })
            }) 
        }

        function getCategories() {
            return new Promise(res => {
                jQuery.ajax({
                    url: litAjax.get_categories,
                    method: 'GET',
                    success: response => {
                        res(response)
                    },
                    error: () => {
                        jQuery.ajax({
                            url: '/?rest_route=/lit/v1/get_categories',
                            method: 'GET',
                            success: response2 => {
                                res(response2)
                            }
                        })
                    }
                })
            })
        }
    })
</script>

