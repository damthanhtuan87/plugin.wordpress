<div class="wrap">
    <h1>Setting</h1>
    <?php settings_errors(); ?>
    <form action="options.php" method="POST">
        <?php
            settings_fields('goro_options_group');
            do_settings_sections('goro_settings');
            submit_button();
        ?>
    </form>
</div>