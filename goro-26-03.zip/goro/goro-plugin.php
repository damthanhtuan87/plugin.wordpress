<?php
/*
 * @package GoroContent
 * Plugin Name: Goro Content
 * Plugin URI: goroauto.com
 * Description: Goro Content
 * Author: Goro
 * Version: 1.0
 */

defined('ABSPATH') or die("You can't access this file!!");

$languages = include __DIR__ . '/languages.php';

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

function activate_goro_plugin() {
    \Goro\Base\Active::activate();
}

function deactivate_goro_plugin() {
    \Goro\Base\Deactive::deactivate();
}

function delete_goro_plugin() {
    \Goro\Base\Deactive::deletePlugin();
}

//activation
register_activation_hook(__FILE__, 'activate_goro_plugin');

//deactivation
register_deactivation_hook(__FILE__, 'deactivate_goro_plugin');

register_uninstall_hook(__FILE__, 'delete_goro_plugin');

if (class_exists('Goro\\Init')) {
    define('GORO_AUTO_MY_API', 'http://admin.goroauto.com');
    define('GORO_AUTO_YOUTUBE_LINK', 'https://www.youtube.com/watch?v=');

    \Goro\Init::boot();
}
