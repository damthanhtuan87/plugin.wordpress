=== Plugin Goroauto ===
Contributors: goro
Donate link: none
Tags: post
Requires at least: 5.2
Tested up to:  1.0
Stable tag: 1.0
Requires PHP: 5.4

== Description ==
Plugin auto post article

== Frequently Asked Questions ==
= How can i get license key? =
Try contact administrator to get key

== Screenshots ==
1. https://goroauto.com/wp-content/uploads/2020/03/goro-banner.png

== Changelog ==
= 1.0 =
* First version.
* Auto load post

== Upgrade Notice ==
= 1.0 =
You need to upgrade for performance and security