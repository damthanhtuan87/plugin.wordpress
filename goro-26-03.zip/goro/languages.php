<?php

return array (
    0 =>
        array (
            'languageCode' => 'ar',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Ả Rập',
                ),
        ),
    1 =>
        array (
            'languageCode' => 'af',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Afrikaans',
                ),
        ),
    2 =>
        array (
            'languageCode' => 'sq',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Albania',
                ),
        ),
    3 =>
        array (
            'languageCode' => 'am',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Amharic',
                ),
        ),
    4 =>
        array (
            'languageCode' => 'en',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Anh',
                ),
        ),
    5 =>
        array (
            'languageCode' => 'hy',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Armenia',
                ),
        ),
    6 =>
        array (
            'languageCode' => 'az',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Azerbaijan',
                ),
        ),
    7 =>
        array (
            'languageCode' => 'pl',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Ba Lan',
                ),
        ),
    8 =>
        array (
            'languageCode' => 'fa',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Ba Tư',
                ),
        ),
    9 =>
        array (
            'languageCode' => 'bn',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Bangla',
                ),
        ),
    10 =>
        array (
            'languageCode' => 'eu',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Basque',
                ),
        ),
    11 =>
        array (
            'languageCode' => 'be',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Belarus',
                ),
        ),
    12 =>
        array (
            'languageCode' => 'bs',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Bosnia',
                ),
        ),
    13 =>
        array (
            'languageCode' => 'pt',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Bồ Đào Nha',
                ),
        ),
    14 =>
        array (
            'languageCode' => 'bg',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Bulgaria',
                ),
        ),
    15 =>
        array (
            'languageCode' => 'ca',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Catalan',
                ),
        ),
    16 =>
        array (
            'languageCode' => 'ceb',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Cebuano',
                ),
        ),
    17 =>
        array (
            'languageCode' => 'co',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Corsica',
                ),
        ),
    18 =>
        array (
            'languageCode' => 'hr',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Croatia',
                ),
        ),
    19 =>
        array (
            'languageCode' => 'iw',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Do Thái',
                ),
        ),
    20 =>
        array (
            'languageCode' => 'da',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Đan Mạch',
                ),
        ),
    21 =>
        array (
            'languageCode' => 'de',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Đức',
                ),
        ),
    22 =>
        array (
            'languageCode' => 'et',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Estonia',
                ),
        ),
    23 =>
        array (
            'languageCode' => 'fy',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Frisia',
                ),
        ),
    24 =>
        array (
            'languageCode' => 'gd',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Gael Scotland',
                ),
        ),
    25 =>
        array (
            'languageCode' => 'gl',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Galician',
                ),
        ),
    26 =>
        array (
            'languageCode' => 'ka',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Georgia',
                ),
        ),
    27 =>
        array (
            'languageCode' => 'gu',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Gujarati',
                ),
        ),
    28 =>
        array (
            'languageCode' => 'nl',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hà Lan',
                ),
        ),
    29 =>
        array (
            'languageCode' => 'ht',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Haiti',
                ),
        ),
    30 =>
        array (
            'languageCode' => 'ko',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hàn',
                ),
        ),
    31 =>
        array (
            'languageCode' => 'ha',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hausa',
                ),
        ),
    32 =>
        array (
            'languageCode' => 'haw',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hawaii',
                ),
        ),
    33 =>
        array (
            'languageCode' => 'hi',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hindi',
                ),
        ),
    34 =>
        array (
            'languageCode' => 'hmn',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hmông',
                ),
        ),
    35 =>
        array (
            'languageCode' => 'hu',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hungary',
                ),
        ),
    36 =>
        array (
            'languageCode' => 'el',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Hy Lạp',
                ),
        ),
    37 =>
        array (
            'languageCode' => 'is',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Iceland',
                ),
        ),
    38 =>
        array (
            'languageCode' => 'ig',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Igbo',
                ),
        ),
    39 =>
        array (
            'languageCode' => 'id',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Indonesia',
                ),
        ),
    40 =>
        array (
            'languageCode' => 'ga',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Ireland',
                ),
        ),
    41 =>
        array (
            'languageCode' => 'it',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Italy',
                ),
        ),
    42 =>
        array (
            'languageCode' => 'jv',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Java',
                ),
        ),
    43 =>
        array (
            'languageCode' => 'kn',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Kannada',
                ),
        ),
    44 =>
        array (
            'languageCode' => 'kk',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Kazakh',
                ),
        ),
    45 =>
        array (
            'languageCode' => 'km',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Khmer',
                ),
        ),
    46 =>
        array (
            'languageCode' => 'ku',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Kurd',
                ),
        ),
    47 =>
        array (
            'languageCode' => 'ky',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Kyrgyz',
                ),
        ),
    48 =>
        array (
            'languageCode' => 'la',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng La-Tinh',
                ),
        ),
    49 =>
        array (
            'languageCode' => 'lo',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Lào',
                ),
        ),
    50 =>
        array (
            'languageCode' => 'lv',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Latvia',
                ),
        ),
    51 =>
        array (
            'languageCode' => 'lt',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Litva',
                ),
        ),
    52 =>
        array (
            'languageCode' => 'lb',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Luxembourg',
                ),
        ),
    53 =>
        array (
            'languageCode' => 'ms',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Mã Lai',
                ),
        ),
    54 =>
        array (
            'languageCode' => 'mk',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Macedonia',
                ),
        ),
    55 =>
        array (
            'languageCode' => 'mg',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Malagasy',
                ),
        ),
    56 =>
        array (
            'languageCode' => 'ml',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Malayalam',
                ),
        ),
    57 =>
        array (
            'languageCode' => 'mt',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Malta',
                ),
        ),
    58 =>
        array (
            'languageCode' => 'mi',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Maori',
                ),
        ),
    59 =>
        array (
            'languageCode' => 'mr',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Marathi',
                ),
        ),
    60 =>
        array (
            'languageCode' => 'my',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Miến Điện',
                ),
        ),
    61 =>
        array (
            'languageCode' => 'mn',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Mông Cổ',
                ),
        ),
    62 =>
        array (
            'languageCode' => 'no',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Na Uy',
                ),
        ),
    63 =>
        array (
            'languageCode' => 'ne',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Nepal',
                ),
        ),
    64 =>
        array (
            'languageCode' => 'ru',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Nga',
                ),
        ),
    65 =>
        array (
            'languageCode' => 'ja',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Nhật',
                ),
        ),
    66 =>
        array (
            'languageCode' => 'ny',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Nyanja',
                ),
        ),
    67 =>
        array (
            'languageCode' => 'ps',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Pashto',
                ),
        ),
    68 =>
        array (
            'languageCode' => 'fr',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Pháp',
                ),
        ),
    69 =>
        array (
            'languageCode' => 'fi',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Phần Lan',
                ),
        ),
    70 =>
        array (
            'languageCode' => 'fil',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Philippines',
                ),
        ),
    71 =>
        array (
            'languageCode' => 'pa',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Punjab',
                ),
        ),
    72 =>
        array (
            'languageCode' => 'eo',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Quốc Tế Ngữ',
                ),
        ),
    73 =>
        array (
            'languageCode' => 'ro',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Romania',
                ),
        ),
    74 =>
        array (
            'languageCode' => 'sm',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Samoa',
                ),
        ),
    75 =>
        array (
            'languageCode' => 'cs',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Séc',
                ),
        ),
    76 =>
        array (
            'languageCode' => 'sr',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Serbia',
                ),
        ),
    77 =>
        array (
            'languageCode' => 'sn',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Shona',
                ),
        ),
    78 =>
        array (
            'languageCode' => 'sd',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Sindhi',
                ),
        ),
    79 =>
        array (
            'languageCode' => 'si',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Sinhala',
                ),
        ),
    80 =>
        array (
            'languageCode' => 'sk',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Slovak',
                ),
        ),
    81 =>
        array (
            'languageCode' => 'sl',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Slovenia',
                ),
        ),
    82 =>
        array (
            'languageCode' => 'so',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Somali',
                ),
        ),
    83 =>
        array (
            'languageCode' => 'st',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Sotho Miền Nam',
                ),
        ),
    84 =>
        array (
            'languageCode' => 'su',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Sunda',
                ),
        ),
    85 =>
        array (
            'languageCode' => 'sw',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Swahili',
                ),
        ),
    86 =>
        array (
            'languageCode' => 'tg',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Tajik',
                ),
        ),
    87 =>
        array (
            'languageCode' => 'ta',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Tamil',
                ),
        ),
    88 =>
        array (
            'languageCode' => 'es',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Tây Ban Nha',
                ),
        ),
    89 =>
        array (
            'languageCode' => 'te',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Telugu',
                ),
        ),
    90 =>
        array (
            'languageCode' => 'th',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Thái',
                ),
        ),
    91 =>
        array (
            'languageCode' => 'tr',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Thổ Nhĩ Kỳ',
                ),
        ),
    92 =>
        array (
            'languageCode' => 'sv',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Thụy Điển',
                ),
        ),
    93 =>
        array (
            'languageCode' => 'zh-Hans',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Trung (Giản Thể)',
                ),
        ),
    94 =>
        array (
            'languageCode' => 'zh-Hant',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Trung (Phồn Thể)',
                ),
        ),
    95 =>
        array (
            'languageCode' => 'uk',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Ukraina',
                ),
        ),
    96 =>
        array (
            'languageCode' => 'ur',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Urdu',
                ),
        ),
    97 =>
        array (
            'languageCode' => 'uz',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Uzbek',
                ),
        ),
    98 =>
        array (
            'languageCode' => 'vi',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Việt',
                ),
        ),
    99 =>
        array (
            'languageCode' => 'cy',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Wales',
                ),
        ),
    100 =>
        array (
            'languageCode' => 'xh',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Xhosa',
                ),
        ),
    101 =>
        array (
            'languageCode' => 'yi',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Yiddish',
                ),
        ),
    102 =>
        array (
            'languageCode' => 'yo',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Yoruba',
                ),
        ),
    103 =>
        array (
            'languageCode' => 'zu',
            'languageName' =>
                array (
                    'simpleText' => 'Tiếng Zulu',
                ),
        ),
);