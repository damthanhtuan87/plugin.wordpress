<?php
/**
 * @package GoroContent
 */

namespace Goro;

use Goro\Api\RouteApi;
use Goro\Base\Enqueue;
use Goro\Base\Schedule;
use Goro\Base\SettingLink;
use Goro\Page\Admin;

final class Init {
    public static function getServices() {
        return [
            Admin::class,
            Enqueue::class,
            SettingLink::class,
            RouteApi::class,
            Schedule::class
        ];
    }

    public static function boot() {
        foreach (self::getServices() as $class) {
            $service = self::instantiate($class);

            if(method_exists($service, 'register')) {
                $service->register();
            }
        }
    }

    private static function instantiate($class) {
        return new $class();
    }
}