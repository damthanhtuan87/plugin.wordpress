<?php

namespace Goro\Base;

class Enqueue extends BaseController {
    public function register() {
        add_action('admin_enqueue_scripts', [
            $this,
            'enqueue'
        ]);

        add_action( 'wp_enqueue_scripts', [
            $this, 'client_enqueue'
        ]);
    }

    function client_enqueue() {
        wp_enqueue_style('goro-style', $this->pluginUrl .'/assets/goro.css');
    }

    function enqueue()
    {

        wp_enqueue_script('goro-script', $this->pluginUrl . '/assets/goro.js');

        if($_GET['page'] == 'goro_content') {
//            wp_register_style('litcss', plugin_dir_url(__FILE__) . 'lit.css');
            wp_register_style('bootstrap4-css', $this->pluginUrl . '/assets/bootstrap.min.css');
            wp_register_style('select2-css', $this->pluginUrl . '/assets/select2.min.css');

            wp_register_script('bootstrap4-js', $this->pluginUrl . '/assets/bootstrap.min.js');
            wp_register_script('select2-js', $this->pluginUrl . '/assets/select2.min.js');
            wp_register_script('notifyjs', $this->pluginUrl . '/assets/notify.min.js');
            wp_register_script("lit_scripts", $this->pluginUrl . '/assets/goro.js', array('jquery'));

            /** setup local variable */
            wp_localize_script('lit_scripts', 'litAjax', array(
//                'addpost' => get_site_url() . '/wp-json/lit/v1/add_post',
//                'fetchlink' => get_site_url() . '/wp-json/lit/v1/fetch_link',
//                'importmulti' => get_site_url() . '/wp-json/lit/v1/import_multi',
//                'get_videos_name' => get_site_url() . '/wp-json/lit/v1/get_videos_name',
                'get_campaign'  => get_site_url() . '/wp-json/lit/v1/get_campaign',
                'delete_campaign'  => get_site_url() . '/wp-json/lit/v1/delete_campaign',
                'stop_campaign'  => get_site_url() . '/wp-json/lit/v1/stop_campaign',
                'get_langs'  => get_site_url() . '/wp-json/lit/v1/get_langs',
                'get_categories'  => get_site_url() . '/wp-json/lit/v1/get_categories',
                'create_campaign'  => get_site_url() . '/wp-json/lit/v1/create_campaign',
            ));

            wp_enqueue_style('bootstrap4-css');
//            wp_enqueue_style('litcss');
            wp_enqueue_style('select2-css');

            // enqueue jQuery library and the script you registered above
            wp_enqueue_script('jquery');
            wp_enqueue_script('lit_scripts');
            wp_enqueue_script('bootstrap4-js');
            wp_enqueue_script('select2-js');
            wp_enqueue_script('notifyjs');

            /** vuejs */
            wp_enqueue_script('vuejs', $this->pluginUrl .'/assets/vue.js');
            wp_enqueue_script('vuemultijs', $this->pluginUrl .'/assets/vue-multiselect.min.js');
            wp_enqueue_script('vuevalidate', $this->pluginUrl .'/assets/vee-validate.js');

            /** notify js */
            wp_enqueue_script('notify', $this->pluginUrl .'/assets/notify.min.js');

            /** css */
            wp_enqueue_style('goro-style', $this->pluginUrl .'/assets/goro.css');
            wp_enqueue_style('vuemulticss', $this->pluginUrl .'/assets/vue-multiselect.min.css');
        }
    }
}