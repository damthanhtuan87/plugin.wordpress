<?php

namespace Goro\Base;

class SettingLink extends BaseController {
    public function register() {
        add_filter('plugin_action_links_' . $this->plugin, [$this, 'settings_link']);
    }

    public function settings_link($link)
    {
        $settings_link = '<a href="admin.php?page=goro_settings">Settings</a>';

        $link[] = $settings_link;

        return $link;
    }
}