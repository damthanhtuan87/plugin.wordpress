<?php
/**
 * @package GoroContent
 */
namespace Goro\Base;

class Deactive {
    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function deletePlugin() {
        flush_rewrite_rules();
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}l_campaign");
        delete_option( 'my_db_version' );
    }
}