<?php
/**
 * @package GoroContent
 */

namespace Goro\Base;

class Schedule
{
    public function register()
    {
        //-gK0t9xhcA0
        //'https://i.ytimg.com/vi/prmrFlaDtMg/maxresdefault.jpg'
        add_action('init', [$this, 'handler']);
    }

    protected function _convertToHtml($content, $autoBreakLine = false)
    {
        try {
            if ($content) {
                $content = json_decode($content);

                if ($autoBreakLine) {
                    $tempStr = implode(' ', $content);

                    if (strpos($tempStr, '.') === false) {
                        $chunk = array_chunk(explode(' ', $tempStr), 50);
                        $result = [];

                        foreach ($chunk as $item) {
                            $result[] = implode(' ', $item) . '<br><br>';
                        }

                        return preg_replace("/\r|\n/", '', str_replace('\n', '', implode($result)));
                    } else {
                        $tempStrArr = explode('.', $tempStr);
                        $resultArr = array_map(function ($item) {
                            return '<p>' . preg_replace("/\r|\n/", '', str_replace(',', ', ', $item)) . ".</p>";
                        }, $tempStrArr);

                        return implode($resultArr);
                    }
                }

                return implode(' ', $content);
            }

            return null;
        } catch (\Exception $exception) {
            return null;
        }
    }

    public function handler() {
        GLOBAL $wpdb;

        $rows = $wpdb->get_results("select * from {$wpdb->prefix}l_campaign where state = 0", ARRAY_A);
        $now = time();
//        if(!is_user_logged_in()) {
//            return;
//        }

//        $pluginlog = plugin_dir_path(__FILE__).'debug.log';
//        $message = 'Go here'.PHP_EOL;
//        error_log($message, 3, $pluginlog);

        foreach ($rows as $item) {
            try {
                if ($item['posted'] >= $item['post_number']) {
                    $wpdb->update("{$wpdb->prefix}l_campaign", [
                        'state' => 1,
                    ], [
                        'id' => $item['id']
                    ]);

                    continue;
                }

                if ($now > $item['next_time']) {
                    if(($item['lock'] == 1) && (time() < $item['unlock_time'])) {
                        continue;
                    }
                    $wpdb->update("{$wpdb->prefix}l_campaign", [
                        'lock' => 1,
                        'unlock_time' => strtotime('+10 minutes')
                    ], [
                        'id' => $item['id']
                    ]);
                    
                    // call to server to post data
                    $keys = explode('|', $item['keyword']);

                    $num = $item['post_number'];

                    foreach ($keys as $key) {
                        if($num - $item['posted'] <= 0) {
                            break;
                        }
                        $number = $num - $item['posted'];
                        $query = http_build_query([
                            'keyword' => $key,
                            'lang' => $item['lang'],
                            'domain' => get_site_url(),
                            'key' => get_option('license_key_4RKdeNKeTu'),
                            'num' => $number > 10 ? 10 : $number,
                            'translate_options' => $item['translate_options']
                        ]);

                        $responseFromSv = wp_remote_get(GORO_AUTO_MY_API . '/api/fetch?' . $query);

                        $output = wp_remote_retrieve_body($responseFromSv);

                        $response = json_decode($output, true);

//                        $pluginlog = plugin_dir_path(__FILE__).'debug.log';
//                        $message = $output.PHP_EOL;
//                        error_log($message, 3, $pluginlog);

                        if ($response['status']) {
                            if(count($response['data']) == 0) {
                                continue;
                            }
                            remove_filter('content_save_pre', 'wp_filter_post_kses');
                            remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');

                            foreach ($response['data'] as $post) {
                                $data['post_title'] = $post['title'];
                                $data['post_status'] = 'publish';
                                $data['post_content'] = $this->_convertToHtml($post['content'], true);
                                $data['post_category'] = json_decode($item['categories']);
                                $data['post_author'] = 0;

                                $postId = wp_insert_post($data);

                                if ($postId) {
                                    $this->Generate_Featured_Image('https://i.ytimg.com/vi/' . $post['i'] . '/maxresdefault.jpg', $postId, $post['i']);
                                }

                                $wpdb->query(
                                    $wpdb->prepare("UPDATE {$wpdb->prefix}l_campaign set posted = posted + 1 where id = %d", $item['id'])
                                );
//                                $wpdb->update("{$wpdb->prefix}l_campaign", [
//                                    'posted' => 'posted + 1',
//                                ], [
//                                    'id' => $item['id']
//                                ]);

                                $item['posted'] += 1;

                                $num -= 1;
                            }

                            add_filter('content_save_pre', 'wp_filter_post_kses');
                            add_filter('content_filtered_save_pre', 'wp_filter_post_kses');

//                            $wpdb->update("{$wpdb->prefix}l_campaign", [
//                                'posted' => $item['posted'] + count($response['data']),
//                            ], [
//                                'id' => $item['id']
//                            ]);
                        }
                    }

                    // update next time to run
                    $wpdb->update("{$wpdb->prefix}l_campaign", [
                        'next_time' => strtotime('+5 minutes', $now),
                        'lock' => 0,
                        'unlock_time' => 0
                    ], [
                        'id' => $item['id']
                    ]);
                }
            } catch(\Exception $exception) {
            }
        }
    }

    private function Generate_Featured_Image($image_url, $post_id, $videoId)
    {
        $upload_dir = wp_upload_dir();

//        $image_data = file_get_contents($image_url);
        $image_data = $this->getImageData($image_url);

        if(!$image_data) {
            try {
                $response = wp_remote_get('http://youtube.com/get_video_info?video_id=' . $videoId);
                $output = wp_remote_retrieve_body($response);

                parse_str($output, $params);
                $thumbnails = json_decode($params['player_response'], true)['videoDetails']['thumbnail']['thumbnails'];

                if(is_countable($thumbnails)) {
                    $image_data = $this->getImageData($thumbnails[count($thumbnails) - 1]['url']);
                }
            } catch(\Exception $exception) {
                return;
            }
        }

        $filename = $post_id . '_' . time() . '_' . basename($image_url);
        if (wp_mkdir_p($upload_dir['path'])) {
            $file = $upload_dir['path'] . '/' . $filename;
        } else {
            $file = $upload_dir['basedir'] . '/' . $filename;
        }
        file_put_contents($file, $image_data);

        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        $res1 = wp_update_attachment_metadata($attach_id, $attach_data);
        $res2 = set_post_thumbnail($post_id, $attach_id);
    }

    private function getImageData($imageUrl) {
        $response = wp_remote_get($imageUrl);
        $httpcode = $response['headers']['status'];
        $image_data = wp_remote_retrieve_body($response);

        return $httpcode == 404 ? null : $image_data;
    }
}