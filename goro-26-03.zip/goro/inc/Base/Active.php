<?php
/**
 * @package GoroContent
 */

namespace Goro\Base;

class Active
{
    public static function activate()
    {
        flush_rewrite_rules();
        self::create_plugin_database_table();
    }

    public static function create_plugin_database_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . "l_campaign";
        $my_products_db_version = '1.0.0';
        $charset_collate = $wpdb->get_charset_collate();

        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {

            $sql = "CREATE TABLE `" . $table_name . "` (
                `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                `name` varchar(255) DEFAULT NULL,
                `keyword` varchar(255) NOT NULL,
                `post_number` int(11) NOT NULL,
                `posted` int(11) DEFAULT '0',
                `lang` varchar(255) NOT NULL,
                `categories` varchar(255) NOT NULL,
                `start_time` int(11) NOT NULL,
                `next_time` int(11) NOT NULL,
                `state` int(11) DEFAULT '0',
                `lock` tinyint(11) DEFAULT '0',
                `unlock_time` int(11) DEFAULT NULL,
                `translate_options` text,
                PRIMARY KEY (`id`)
            ) $charset_collate";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
            add_option('my_db_version', $my_products_db_version);
        }
    }
}