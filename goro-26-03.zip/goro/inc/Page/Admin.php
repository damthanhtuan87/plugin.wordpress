<?php

namespace Goro\Page;

use Goro\Api\SettingsApi;
use Goro\Base\BaseController;

class Admin extends BaseController {
    public $settings;
    public $pages = [];
    public $subPages = [];

    public function __construct()
    {
        parent::__construct();
        $this->settings = new SettingsApi();
        $this->setPages();
        $this->setSubPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();
    }

    public function setPages() {
        global $languages;
        global $wpdb;
        $categories = get_categories([
            'hide_empty' => 0
        ]);

        $categoriesJson = json_encode($categories);
        $languagesJson = json_encode($languages);

        $rows = json_encode($wpdb->get_results("select * from {$wpdb->prefix}l_campaign", ARRAY_A));

        $this->pages = [
            [
                'page_title' => 'Goro Content',
                'menu_title' => 'Goro Content',
                'capability' => 'manage_options',
                'menu_slug' => 'goro_content',
                'callback' => function() use ($categoriesJson, $languagesJson, $rows) {
                    set_query_var('categories', $categoriesJson);
                    set_query_var('languages', $languagesJson);
                    set_query_var('data', $rows);
                    load_template($this->pluginPath . '/templates/index.php');
                }
            ]
        ];
    }

    public function setSubPages() {
        $this->subPages = [
            [
                'parent_slug' => 'goro_content',
                'page_title' => 'Settings',
                'menu_title' => 'Settings',
                'capability' => 'manage_options',
                'menu_slug' => 'goro_settings',
                'callback' => function() {

                    load_template($this->pluginPath . '/templates/settings.php');
                }
            ]
        ];
    }

    public function setSettings() {
        $args = [
            [
                'option_group' => 'goro_options_group',
                'option_name' => 'license_key_4RKdeNKeTu',
                'callback' => function($input) {
                    if(!strlen($input)) {
                        add_settings_error('license_key_4RKdeNKeTu','','License cannot empty!','error');
                        return get_option('license_key_4RKdeNKeTu');
                    } else {
                        $query = http_build_query([
                            'key' => $input,
                            'domain' => get_site_url()
                        ]);

                        /** change */
                        $response = wp_remote_get(GORO_AUTO_MY_API . '/api/register-license?' . $query);
                        $check = wp_remote_retrieve_body($response);

                        if(!$check) {
                            add_settings_error('license_key_4RKdeNKeTu','','Cannot register license!','error');
                            return get_option('license_key_4RKdeNKeTu');
                        }

                        $result = json_decode($check);

                        if($result->status) {
                            add_settings_error('license_key_4RKdeNKeTu', '', 'Register license key success!', 'updated');
                            return $input;
                        } else {
                            add_settings_error('license_key_4RKdeNKeTu','', $result->message,'error');
                            return get_option('license_key_4RKdeNKeTu');
                        }
                    }
                }
            ],
            [
                'option_group' => 'goro_options_group',
                'option_name' => 'translate_key',
                'callback' => function($input) {
                    return $input;
                }
            ]
        ];

        $this->settings->addSettings($args);
    }

    public function setSections() {
        $args = [
            [
                'id' => 'goro_admin_index',
                'title' => 'Setup license key',
                'callback' => function() {

                },
                'page' => 'goro_settings'
            ]
        ];

        $this->settings->addSections($args);
    }

    public function setFields() {
        $args = [
            [
                'id' => 'license_key_4RKdeNKeTu',
                'title' => 'License',
                'callback' => function() {
                    $value = esc_attr(get_option('license_key_4RKdeNKeTu'));
                    echo '<input type="text" class="regular-text" name="license_key_4RKdeNKeTu" value="'.$value.'" placeholder="Enter license key"/>';
                },
                'page' => 'goro_settings',
                'section' => 'goro_admin_index',
                'args' => [
                    'label_for' => 'license_key_4RKdeNKeTu',
                    'class' => 'example-class'
                ]
            ],
            [
                'id' => 'translate_key',
                'title' => 'Translate key',
                'callback' => function() {
                    $value = esc_attr(get_option('translate_key'));
                    echo '<input type="text" class="regular-text" name="translate_key" value="'.$value.'" placeholder="Enter translate key"/>';
                },
                'page' => 'goro_settings',
                'section' => 'goro_admin_index',
                'args' => [
                    'label_for' => 'translate_key',
                    'class' => 'example-class'
                ]
            ]
        ];

        $this->settings->addFields($args);
    }

    public function register() {
        $this->settings->addPages($this->pages)->addSubPage($this->subPages)->register();
    }

//    public function add_admin_pages()
//    {
//        add_menu_page('Goro Content', 'Goro Content', 'manage_options', 'goro_content', [$this, 'admin_index']);
//    }
//
//    public function admin_index()
//    {
//        //load_template(__DIR__.'/views/active-page.php');
//        load_template($this->pluginPath . '/templates/index.php');
//    }
}