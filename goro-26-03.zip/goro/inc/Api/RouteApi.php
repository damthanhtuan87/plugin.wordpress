<?php

namespace Goro\Api;

use Goro\Base\BaseController;
use SimpleXMLElement;

class RouteApi extends BaseController
{
    public $routes = [];

    public function register()
    {
        $this->setRoutes();
        add_action('rest_api_init', [$this, 'fetchRoute']);
    }

    protected function set($namespace, $route, $method = 'GET', $callback = '')
    {
        $this->routes[] = [
            'namespace' => $namespace,
            'route' => $route,
            'args' => [
                'methods' => $method,
                'callback' => $callback
            ]
        ];
    }

    public function setRoutes()
    {
        GLOBAL $wpdb;

        $this->set('lit/v1', '/get_campaign', 'GET', function () use ($wpdb) {
            $rows = $wpdb->get_results("select * from {$wpdb->prefix}l_campaign", ARRAY_A);

            return $rows;
        });

        $this->set('lit/v1', '/delete_campaign', 'POST', function () use ($wpdb) {
            $campaignId = sanitize_text_field($_POST['id']);

            $query = $wpdb->prepare("DELETE FROM {$wpdb->prefix}l_campaign where id=%d", $campaignId);
            $result = $wpdb->query($query);

            return $result;
        });

        $this->set('lit/v1', '/get_langs', 'GET', function () {
            GLOBAL $languages;

            return $languages;
        });

        $this->set('lit/v1', '/stop_campaign', 'POST', function() use ($wpdb) {
            $campaignId = sanitize_text_field($_POST['id']);

            $query = $wpdb->prepare("UPDATE {$wpdb->prefix}l_campaign SET state = 1 where id=%d", $campaignId);
            $result = $wpdb->query($query);

            return $result;
        });

        $this->set('lit/v1', '/get_categories', 'GET', function () {
            $categories = get_categories([
                'hide_empty' => 0
            ]);

            return $categories;
        });

        $this->set('lit/v1', '/create_campaign', 'POST', function () use ($wpdb) {
            $data = sanitize_post($_POST);

            try {
                if (!count($data['keywords']) || !count($data['categories']) || !$data['post_number'] || !$data['lang']) {
                    return [
                        'status' => false,
                        'message' => 'Form missing fields'
                    ];
                }

                $keywords = implode('|', $data['keywords']);

                /** check */
                $queryData = [
                    'keywords' => $keywords,
                    'lang' => $data['lang'],
                    'domain' => get_site_url(),
                    'key' => get_option('license_key_4RKdeNKeTu')
                ];

                $translateOptions = [];
                if($data['translate']) {
                    if(!get_option('translate_key')) {
                        return [
                            'status' => false,
                            'message' => 'Please enter your translate key before create campaign'
                        ];
                    }

                    $translateOptions = [
                        'translate' => $data['translate'] ? 1 : 0,
                        'to' => $data['to'],
                        'translateKey' => get_option('translate_key'),
                        'lang' => $data['lang']
                    ];
                }

                $query = http_build_query(array_merge($queryData, $translateOptions));

                $responseFromSv = wp_remote_get(GORO_AUTO_MY_API . '/api/search/keyword?'.$query);
                $output = wp_remote_retrieve_body($responseFromSv);

                $response = json_decode($output, true);

                if(!$response['status']) {
                    return $response;
                }

                $categories = json_encode($data['categories']);
                $start_time = time();
                $next_time = strtotime('+5 minutes', $start_time);

                $row = $wpdb->insert("{$wpdb->prefix}l_campaign", [
                    'keyword' => $keywords,
                    'post_number' => $data['post_number'],
                    'lang' => $data['lang'],
                    'categories' => $categories,
                    'name' => $data['name'],
                    'start_time' => $start_time,
                    'next_time' => $next_time,
                    'translate_options' => $data['translate'] ? json_encode($translateOptions) : null
                ]);

                if(!$row) {
                    return [
                        'status' => false,
                        'message' => 'Cannot create campaign. Please contact administrator'
                    ];
                }

                return [
                    'status' => true,
                    'message' => 'Create compaign success'
                ];
            } catch (\Exception $exception) {
                return [
                    'status' => false,
                    'message' => 'Please contact admin'
                ];
            }
        });
    }

    public function fetchRoute()
    {
        foreach ($this->routes as $route) {
            register_rest_route($route['namespace'], $route['route'], $route['args']);
        }
    }
}